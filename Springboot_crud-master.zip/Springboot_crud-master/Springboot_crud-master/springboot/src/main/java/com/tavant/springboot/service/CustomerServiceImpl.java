package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.CustomerDao;
import com.tavant.springboot.dao.OrderDao;
import com.tavant.springboot.model.Customers;
@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerDao customerDao;

	@Override
	public boolean addCustomer(Customers cust) {
		// TODO Auto-generated method stub
		return this.customerDao.addCustomer(cust);
	}

	@Override
	public Optional<Customers> updateCustomer(String Code, Customers cust) throws InvalidNameException {
		// TODO Auto-generated method stub
		return this.customerDao.updateCustomer(Code,cust);
	}

	@Override
	public Optional<List<Customers>> getCustomers() {
		// TODO Auto-generated method stub
		return this.customerDao.getCustomers();
	}

	@Override
	public Optional<Customers> getCustomerByNumber(String Code) {
		// TODO Auto-generated method stub
		return this.customerDao.getCustomerByNumber(Code);
	}

	@Override
	public boolean isExists(String customerCode) {
		// TODO Auto-generated method stub
		return this.customerDao.isExists(customerCode);
	}

	@Override
	public Optional<Customers> deleteCustomer(String cust) {
		// TODO Auto-generated method stub
		return this.customerDao.deleteCustomer(cust);
	}

}
