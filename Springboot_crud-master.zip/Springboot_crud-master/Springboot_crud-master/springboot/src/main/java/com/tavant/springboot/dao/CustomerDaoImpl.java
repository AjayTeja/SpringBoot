package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Customers;
import com.tavant.springboot.model.Orders;
import com.tavant.springboot.utils.DBUtils;
@Repository
public class CustomerDaoImpl implements CustomerDao {
	@Autowired
	DBUtils dbUtils;
	@Override
	public boolean addCustomer(Customers cust) {
		// TODO Auto-generated method stub
		
		String insertStatement = "insert into customers (customerNumber,customerName,contactLastName,contactFirstName,phone,addressLine1,addressLine2,city,state,postalCode,country,salesRepEmployeeNumber,creditLimit) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			System.out.println("hello");
			preparedStatement.setString(1, cust.getCustomerNumber());
			preparedStatement.setString(2, cust.getCustomerName());
			preparedStatement.setString(3,cust.getContactLastName());
			preparedStatement.setString(4,cust.getContactFirstName());
			preparedStatement.setString(5, cust.getPhone());
			preparedStatement.setString(6, cust.getAddressLine1());
			preparedStatement.setString(7, cust.getAddressLine2());
			preparedStatement.setString(8, cust.getCity());
			preparedStatement.setString(9, cust.getState());
			preparedStatement.setString(10, cust.getPostalCode());
			preparedStatement.setString(11, cust.getCountry());
			preparedStatement.setString(12, cust.getSalesRepEmployeeNumber());
			preparedStatement.setString(13, cust.getCreditLimit());
			
			int result = preparedStatement.executeUpdate();
			if(result>0)
				return true;
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}
		
	@Override
	public Optional<Customers> updateCustomer(String Code, Customers cust) throws InvalidNameException {
		// TODO Auto-generated method stub
		
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = " Update customers set customerNumber = ? , customerName = ? , contactLastName = ? , contactFirstName = ? , Phone = ? , AddressLine1 = ? , AddressLine2 = ?, city = ?, state= ?, postalCode =?, country = ?, salesRepEmployeeNumber =?, creditLimit = ? where customerNumber = ?";
        connection = dbUtils.getConnection();
        try {
        	preparedStatement.setString(1, cust.getCustomerNumber());
			preparedStatement.setString(2, cust.getCustomerName());
			preparedStatement.setString(3,cust.getContactLastName());
			preparedStatement.setString(4,cust.getContactFirstName());
			preparedStatement.setString(5, cust.getPhone());
			preparedStatement.setString(6, cust.getAddressLine1());
			preparedStatement.setString(7, cust.getAddressLine2());
			preparedStatement.setString(8, cust.getCity());
			preparedStatement.setString(9, cust.getState());
			preparedStatement.setString(10, cust.getPostalCode());
			preparedStatement.setString(11, cust.getCountry());
			preparedStatement.setString(12, cust.getSalesRepEmployeeNumber());
			preparedStatement.setString(13, cust.getCreditLimit());
			
        	
            int result = preparedStatement.executeUpdate();
            System.out.println(result);
            return Optional.of(cust);
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            dbUtils.closeConnection(connection);
        }
       
       
        return Optional.empty();
   

	}
		
		
	@Override
	public Optional<List<Customers>> getCustomers() {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Customers> customer = new ArrayList<Customers>();
		
		String query = "select * from customers";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
		
			while(resultSet.next()) {
				
				Customers cust = new Customers();
				cust.setCustomerNumber(resultSet.getString("customerNumber"));
				cust.setCustomerName(resultSet.getString("customerName"));
				cust.setContactLastName(resultSet.getString("ContactLastName"));
				cust.setContactFirstName(resultSet.getString("contactFirstName"));
				cust.setPhone(resultSet.getString("phone"));
				cust.setAddressLine1(resultSet.getString("addressLine1"));
				cust.setAddressLine2(resultSet.getString("addressLine2"));
				cust.setCity(resultSet.getString("city"));
				cust.setState(resultSet.getString("state"));
				cust.setPostalCode(resultSet.getString("postalCode"));
				cust.setCountry(resultSet.getString("country"));
				cust.setSalesRepEmployeeNumber(resultSet.getString("salesRepEmployeeNumber"));
				cust.setCreditLimit(resultSet.getString("creditLimit"));
				System.out.println(cust);
				// then can i add the data into the list by calling add method?
				Customers.add(cust);
				
			}
			return Optional.of(customer);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
		
	}

	
	

	@Override
	public Optional<Customers> getCustomerByNumber(String Code) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from customers where customerNumber =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(Code));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Customers cust = new Customers();
				cust.setCustomerNumber(resultSet.getString("customerNumber"));
				cust.setCustomerName(resultSet.getString("customerName"));
				cust.setContactLastName(resultSet.getString("ContactLastName"));
				cust.setContactFirstName(resultSet.getString("contactFirstName"));
				cust.setPhone(resultSet.getString("phone"));
				cust.setAddressLine1(resultSet.getString("addressLine1"));
				cust.setAddressLine2(resultSet.getString("addressLine2"));
				cust.setCity(resultSet.getString("city"));
				cust.setState(resultSet.getString("state"));
				cust.setPostalCode(resultSet.getString("postalCode"));
				cust.setCountry(resultSet.getString("country"));
				cust.setSalesRepEmployeeNumber(resultSet.getString("salesRepEmployeeNumber"));
				cust.setCreditLimit(resultSet.getString("creditLimit"));
				System.out.println(cust);
				return Optional.of(cust);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
	}


	

	@Override
	public boolean isExists(String cust) {
		// TODO Auto-generated method stub
		return false;
	}

	
	@Override
	public Optional<Customers> deleteCustomer(String cust) {
		// TODO Auto-generated method stub
		return null;
	}

}
