package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.utils.DBUtils;
@Repository
public class OfficeDaoImpl implements OfficeDao {
	@Autowired
	DBUtils dbUtils;

	@Override
	public boolean addOffice(Office office) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into offices (officeCode,city,phone,addressLine1,addressLine2,state,country,postalCode,territory) values(?,?,?,?,?,?,?,?,?)";
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			System.out.println("hello");
			preparedStatement.setString(1, office.getOfficeCode());
			preparedStatement.setString(2, office.getCity());
			preparedStatement.setString(3, office.getPhone());
			preparedStatement.setString(4, office.getAddressLine1());
			preparedStatement.setString(5, office.getAddressLine2());
			preparedStatement.setString(6, office.getState());
			preparedStatement.setString(7, office.getCountry());
			preparedStatement.setString(8, office.getPostalCode());
			preparedStatement.setString(9, office.getTerritory());
			int result = preparedStatement.executeUpdate();
			if(result>0)
				return true;
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}
	@Override
	public Optional<Office> updateOffice(String Code, Office office) throws InvalidNameException {
		// TODO Auto-generated method stub
			Connection connection = null;
	        PreparedStatement preparedStatement = null;
	        String query = " Update offices set officeCode = ? , city = ? , phone = ? , addressLine1 = ? , addressLine2 = ? , state = ? , country = ? , postalCode =?, territory =? where officeCode = ?";
	        connection = dbUtils.getConnection();
	        try {
	            preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setString(1, office.getOfficeCode());
				preparedStatement.setString(2, office.getCity());
				preparedStatement.setString(3, office.getPhone());
				preparedStatement.setString(4, office.getAddressLine1());
				preparedStatement.setString(5, office.getAddressLine2());
				preparedStatement.setString(6, office.getState());
				preparedStatement.setString(7, office.getCountry());
				preparedStatement.setString(8, office.getPostalCode());
				preparedStatement.setString(9, office.getTerritory());
	            int result = preparedStatement.executeUpdate();
	            System.out.println(result);
	            return Optional.of(office);
	           
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        finally {
	            dbUtils.closeConnection(connection);
	        }
	       
	       
	        return Optional.empty();
	    

			// TODO Auto-generated method stub
			//here we need to compare the database details with the provided one and update the contents accordingly.
			
	}

	@Override
	public Optional<List<Office>> getOffices() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Office> Office = new ArrayList<Office>();
		
		String query = "select * from offices";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Office office = new Office();
				office.setOfficeCode(resultSet.getString("officeCode"));
				office.setCity(resultSet.getString("city"));
				office.setPhone(resultSet.getString("phone"));
				office.setAddressLine1(resultSet.getString("addressLine1"));
				office.setAddressLine2(resultSet.getString("addressLine2"));
				office.setState(resultSet.getString("state"));
				office.setCountry(resultSet.getString("country"));
				office.setPostalCode(resultSet.getString("postalCode"));
				office.setTerritory(resultSet.getString("territory"));
				//System.out.println(office);
				// then can i add the data into the list by calling add method?
				Office.add(office);
				
			}
			return Optional.of(Office);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public Optional<Office> getOfficeByNumber(String Code) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from offices where officeCode =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(Code));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Office office = new Office();
				office.setOfficeCode(resultSet.getString("officeCode"));
				office.setCity(resultSet.getString("city"));
				office.setPhone(resultSet.getString("phone"));
				office.setAddressLine1(resultSet.getString("addressLine1"));
				office.setAddressLine2(resultSet.getString("addressLine2"));
				office.setState(resultSet.getString("state"));
				office.setCountry(resultSet.getString("country"));
				office.setPostalCode(resultSet.getString("postalCode"));
				office.setTerritory(resultSet.getString("territory"));
				System.out.println(office);
				return Optional.of(office);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
	}

	@Override
	public boolean isExists(String officeCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Office> deleteOffice(String officeCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
