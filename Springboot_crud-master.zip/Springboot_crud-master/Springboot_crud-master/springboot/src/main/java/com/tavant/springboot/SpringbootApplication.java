package com.tavant.springboot;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.tavant.springboot.service.EmployeeService;
import com.tavant.springboot.utils.DBUtils;



import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import javax.naming.InvalidNameException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.tavant.springboot.exceptions.InvalidLocationNameException;
import com.tavant.springboot.exceptions.InvalidSalaryException;
//import com.tavant.springboot.exception.InvalidLocationNameException;
//import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Customers;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Orders;
import com.tavant.springboot.model.ProductLines;
import com.tavant.springboot.model.Products;
import com.tavant.springboot.service.CustomerService;
import com.tavant.springboot.service.EmployeeService;
import com.tavant.springboot.service.EmployeeServiceImpl;
import com.tavant.springboot.service.OfficeService;
import com.tavant.springboot.service.OrderService;
import com.tavant.springboot.service.ProductLinesService;
import com.tavant.springboot.service.ProductsService;

@SpringBootApplication
public class SpringbootApplication {

	public static void main(String[] args) throws InvalidSalaryException, InvalidNameException,  InvalidLocationNameException {
		
				ApplicationContext context = SpringApplication.run(SpringbootApplication.class, args);
			
			//	Arrays.asList(context.getBeanDefinitionNames()).forEach(System.out::println);
				EmployeeService employeeService = context.getBean(EmployeeService.class);
				//System.out.println(employeeService!=null);
				//DBUtils dbUtils = context.getBean(DBUtils.class);
				//System.out.println(dbUtils.getConnection());
				//employeeService.getEmployees().get().forEach(System.out::println);
		//dept Dept = new dept();
		boolean b=true;
	//EmployeeService employeeService = new EmployeeServiceImpl(); 
	
		//ApplicationContext context = SpringApplication.run(SpringbootApplication.class, args);
	//	EmployeeService employeeService = context.getBean(EmployeeService.class);
		OfficeService officeService = context.getBean(OfficeService.class);
		ProductsService productsService = context.getBean(ProductsService.class);
		ProductLinesService productlinesService = context.getBean(ProductLinesService.class);
		OrderService orderService = context.getBean(OrderService.class);
		CustomerService customerService = context.getBean(CustomerService.class);
		
		System.out.println(employeeService!=null);
		System.out.println(officeService!=null);
		System.out.println(productsService!=null);
		System.out.println(productsService!=null);
		try(Scanner scanner = new Scanner(System.in)){
			int choice = 0;
			int flag = 0;
			while(b) {
				System.out.println("enter \n 1 for employee  \n 2 for offices \n 3 for Products\n 4 for productlines \n 5 orders \n 6 customers \n");
				flag = scanner.nextInt();
				
			switch(flag ) {
			case 1: //employees
			
			while (b) {
				System.out.println("enter ur choice \n 1.add employee \n 2.update employee \n 3.get employee by id \n 4. get all employee details \n 5.delete employee");
				choice = scanner.nextInt();
				
				switch (choice) {
				case 1:
	                 Employee employee = new Employee(1939,"alekya","lavanya","dsfwsjhs","ale@gmail.com","4",1002,"manager");
		             boolean result = employeeService.addEmployee(employee);
	                 System.out.println("insert result= "+result);	
	                 break;
				case 2:
		        
             		 Employee employee1 = new Employee(1165,"alekyy","alee","awreshs","alekya@gmail.com","4",1002,"manager");
	                	
					try {
						employeeService.updateEmployee(1165, employee1);
					} catch (InvalidSalaryException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (com.tavant.springboot.exceptions.InvalidNameException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	      
		                
	                	break;
				case 3:
					
		             employeeService.getEmployeeById(1143);
		             break;
		             
				case 4:
		
	                 Optional<List<Employee>> optional = employeeService.getEmployees();
		             if(optional.isPresent()) {
			         optional.get().forEach(System.out::println);
		             } 
	                 else {
			         System.out.println("there is no record");
		             }
		             break;
		            
				case 5:				
	             employeeService.deleteEmploye(1143);
	             break;
		             
				case 6: 
					// exists method call
					break;
				
				default:
					break;
				}
		
	}
			case 2: //offices
			{
				while (b) {
					System.out.println("enter ur choice\n");
					choice = scanner.nextInt();
					
					switch (choice) {
					case 1:
		                 Office office = new Office("8","tuni","786868677","fddhdjfd","jhdjshsjhjs","AndhraPradesh","India","94080","JSHSH");
			             boolean result = officeService.addOffice(office);
		                 System.out.println("insert result= "+result);	
		                 break;
					case 2:
			        
	             		 Office office1 = new Office("8","tuni","7868676777","fdhghjfd","jhdjshsjhjs","AndhraPradesh","India","94080","JSHSH");
		                	try {
			             	officeService.updateOffice("8", office1);
		                   	} catch (InvalidNameException e) {
				// TODO Auto-generated catch block
				            e.printStackTrace();
			                }
		                	break;
					case 3:
						
			             officeService.getOfficeByNumber("7");
			             break;
			             
					case 4:
			
		                 Optional<List<Office>> optional = officeService.getOffices();
			             if(optional.isPresent()) {
				         optional.get().forEach(System.out::println);
			             } 
		                 else {
				         System.out.println("there is no record");
			             }
			             break;
			            
					case 5:
						
////			
//			             employeeService.deleteEmploye(1143);
//			             break;
			             
					case 6: 
						// exists method call
						break;
					
					default:
						break;
					}
			
		}
			}
				
			case 3:
			{
				
				while (b) {
					System.out.println("enter ur choice\n");
					choice = scanner.nextInt();
					
					switch (choice) {
					case 1:
		                 Products products = new Products("S72_3233","alee","Ships","1:72","Unimax Art Galleries","books",333,33.30,54.60);
			             boolean result = productsService.addProducts(products);
		                 System.out.println("insert result= "+result);	
		                 break;
					case 2:
			        
					       Products products1 = new Products("S72_3212","alee","Ships","1:72","Unimax Art Galleries","books",333,33.30,54.60);
		                	try {
			             	productsService.updateProducts("S72_3212", products1);
		                   	} catch (InvalidNameException e) {
				// TODO Auto-generated catch block
				            e.printStackTrace();
			                }
		                	break;
					case 3:
						
			             productsService.getProductsByCode("S72_3233");
			             break;
			             
					case 4:
			
		                 Optional<List<Products>> optional = productsService.getProducts();
			             if(optional.isPresent()) {
				         optional.get().forEach(System.out::println);
			             } 
		                 else {
				         System.out.println("there is no record");
			             }
			             break;
			            
					case 5:
						
////			
//			             employeeService.deleteEmploye(1143);
//			             break;
			             
					case 6: 
						// exists method call
						//exits(0);
						break;
					
					default:
						break;
					}
			
		}
			
			}
			
			
			case 4:
			{
				
				while (b) {
					System.out.println("enter ur choice\n");
					choice = scanner.nextInt();
					
					switch (choice) {
					case 1:
		                 ProductLines productlines = new ProductLines("Trucks and Buses","alekya"," "," ");
			             boolean result = productlinesService.addProductLines(productlines);
		                 System.out.println("insert result= "+result);	
		                 break;
					case 2:
			        
						 ProductLines productlines1 = new ProductLines("Trucks and Buses","alekya"," "," ");
		                	try {
			             	productlinesService.updateProductLines("Trucks and Buses", productlines1);
		                   	} catch (InvalidNameException e) {
				// TODO Auto-generated catch block
				            e.printStackTrace();
			                }
		                	break;
					case 3:
						
			             productlinesService.getProductLinesByName("Trucks and Buses");
			             break;
			             
					case 4:
			
		                 Optional<List<ProductLines>> optional = productlinesService.getProductLines();
			             if(optional.isPresent()) {
				         optional.get().forEach(System.out::println);
			             } 
		                 else {
				         System.out.println("there is no record");
			             }
			             break;
			            
					case 5:
						
////			
//			             employeeService.deleteEmploye(1143);
//			             break;
			             
					case 6: 
						// exists method call
						//exits(0);
						break;
					
					default:
						break;
				
				
			}
			
			
			}
			
			}
			
			case 5:
			{
			
	 //orders
				
				while (b) {
					System.out.println("enter ur choice\n");
					choice = scanner.nextInt();
					
					switch (choice) {
					case 1:
			             Orders order = new Orders("426","2003-01-06","2003-01-31","2003-01-21","shipped","gfgdfg","187");
			             boolean result = orderService.addOrder(order);
			             System.out.println("insert result= "+result);	
			             break;
					case 2:
			        
			     		 Orders order1 = new Orders("426","2003-01-06","2003-01-31","2003-01-21","delivered","gfgdfg","187");
			            	try {
			             	orderService.updateOrder("426", order1);
			               	} catch (InvalidNameException e) {
				// TODO Auto-generated catch block
				            e.printStackTrace();
			                }
			            	break;
					case 3:
						
			             orderService.getOrderByNumber("10100");
			             break;
			             
					case 4:

			             Optional<List<Orders>> optional = orderService.getOrders();
			             if(optional.isPresent()) {
				         optional.get().forEach(System.out::println);
			             } 
			             else {
				         System.out.println("there is no record");
			             }
			             break;
			            
					case 5:
						
			////
//			             employeeService.deleteEmploye(1143);
//			             break;
			             
					case 6: 
						// exists method call
						break;
					
					default:
						break;
					}

			}
			
			             
						}
			
			
			case 6: //orders
			{
				while (b) {
					System.out.println("enter ur choice\n");
					choice = scanner.nextInt();
					
					switch (choice) {
					case 1:
			             Customers cust = new Customers("489","gvghfghv","hghjghgh","ghfvghvgvg","8967766777","gfgdfg","hgfghfgg","tuni","dsfgdfg","3012","hjghg","1621","81200");
			             boolean result = customerService.addCustomer(cust);
			             System.out.println("insert result= "+result);	
			             break;
					case 2:
			        
			     		 Customers cust1 = new Customers("489","gvghfghv","hghjghgh","ghfvghvgvg","8967766777","gfgdfg","hgfghfgg","tuni","dsfgdfg","3012","hjghg","1621","81200");
			            	try {
			             	customerService.updateCustomer("489", cust1);
			               	} catch (InvalidNameException e) {
				// TODO Auto-generated catch block
				            e.printStackTrace();
			                }
			            	break;
					case 3:
						
			             customerService.getCustomerByNumber("489");
			             break;
			             
					case 4:

			             Optional<List<Customers>> optional = customerService.getCustomers();
			             if(optional.isPresent()) {
				         optional.get().forEach(System.out::println);
			             } 
			             else {
				         System.out.println("there is no record");
			             }
			             break;
			            
					case 5:
						
			////
//			             employeeService.deleteEmploye(1143);
//			             break;
					case 6: 
						// exists method call
						break;
					
					default:
						break;
					}

			}
				}
			}
		
			}
		}
	}

	}

