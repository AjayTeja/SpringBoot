package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.ProductLines;
import com.tavant.springboot.model.ProductLines;
import com.tavant.springboot.utils.DBUtils;
@Repository
public class ProductLinesDaoImpl implements ProductLinesDao {
	@Autowired
	DBUtils dbUtils;

	@Override
	public boolean addProductLines(ProductLines productlines) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into productlines (productline,textDescription,htmlDescription,image) values(?,?,?,?)";
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			System.out.println("hello");
			preparedStatement.setString(1, productlines.getProductLine());
			preparedStatement.setString(2, productlines.getTextDescription());
			preparedStatement.setString(3, productlines.getHtmlDescription());
			preparedStatement.setString(4, productlines.getImage());
			int result = preparedStatement.executeUpdate();
			if(result>0)
				return true;
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}

	@Override
	public Optional<ProductLines> updateProductLines(String pName, ProductLines productlines)
			throws InvalidNameException {
		// TODO Auto-generated method stub
		
		
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = " Update productlines set productline = ? , textDescription = ? , htmlDescription = ? , image = ?  where productline = ?";
        connection = dbUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, productlines.getProductLine());
			preparedStatement.setString(2, productlines.getTextDescription());
			preparedStatement.setString(3, productlines.getHtmlDescription());
			preparedStatement.setString(4, productlines.getImage());
			int result = preparedStatement.executeUpdate();
            System.out.println(result);
            return Optional.of(productlines);
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            dbUtils.closeConnection(connection);
        }
       
       
        return Optional.empty();
	}

	@Override
	public Optional<List<ProductLines>> getProductLines() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<ProductLines> ProductLines = new ArrayList<ProductLines>();
		
		String query = "select * from productlines";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				ProductLines productlines = new ProductLines();
				productlines.setProductLine(resultSet.getString("productline"));
				productlines.setTextDescription(resultSet.getString("textDescription"));
				productlines.setHtmlDescription(resultSet.getString("htmlDescription"));
				productlines.setImage(resultSet.getString("image"));
				
				//System.out.println(productlines);
				// then can i add the data into the list by calling add method?
				ProductLines.add(productlines);
				
			}
			return Optional.of(ProductLines);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public Optional<ProductLines> getProductLinesByName(String pName) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from productlines where officeCode =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setString(1,pName);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				ProductLines productlines = new ProductLines();
				productlines.setProductLine(resultSet.getString("productline"));
				productlines.setTextDescription(resultSet.getString("textDescription"));
				productlines.setHtmlDescription(resultSet.getString("htmlDescription"));
				productlines.setImage(resultSet.getString("image"));
				System.out.println(productlines);
				return Optional.of(productlines);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
		
	}

	@Override
	public boolean isExists(String pName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<ProductLines> deleteProductLines(String pName) {
		// TODO Auto-generated method stub
		return null;
	}

}
