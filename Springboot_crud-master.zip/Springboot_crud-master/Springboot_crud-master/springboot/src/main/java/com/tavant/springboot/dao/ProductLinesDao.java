package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.ProductLines;
import com.tavant.springboot.model.Products;

public interface ProductLinesDao {

	public boolean addProductLines(ProductLines productlines);
	public Optional<ProductLines> updateProductLines(String pName,ProductLines productlines)throws InvalidNameException;
	public Optional<List<ProductLines>> getProductLines();
	public Optional<ProductLines> getProductLinesByName(String pName);
	public boolean isExists(String pName);
	public Optional<ProductLines> deleteProductLines(String pName);
}
